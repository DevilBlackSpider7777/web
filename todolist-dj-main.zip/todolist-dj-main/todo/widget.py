from django import forms


class datePickerInput(forms.DateInput):
    input_type = 'date'
